var searchData=
[
  ['add_4',['add',['../classtoolbox_1_1kd_tree_k_n_n_classifier_1_1_kd_tree_1_1_large_heap.html#a4ac955479798c0a601aa3f91c368b429',1,'toolbox::kdTreeKNNClassifier::KdTree::LargeHeap']]],
  ['apriori_5',['apriori',['../classtoolbox_1_1_transaction_data_set.html#a42c55315b94f83793629a1d684ea8db6',1,'toolbox::TransactionDataSet']]],
  ['askk_6',['askK',['../classtoolbox_1_1simplek_n_n_classifier.html#ad9487fab8cbf77b01acbba645176b283',1,'toolbox.simplekNNClassifier.askK()'],['../classtoolbox_1_1kd_tree_k_n_n_classifier.html#aefd43f41c790ae12f8033d03cf602b22',1,'toolbox.kdTreeKNNClassifier.askK()']]],
  ['attribute_5fbased_5fon_5fginiindex_7',['attribute_based_on_Giniindex',['../classtoolbox_1_1_decision_tree.html#a559705e1c0750c67c1cfbf940dd9daec',1,'toolbox::DecisionTree']]]
];
