var searchData=
[
  ['find_5fneighbors_157',['find_neighbors',['../classtoolbox_1_1lshk_n_n_classifier.html#a2ab4952081caddf94f1f6139db97692d',1,'toolbox::lshkNNClassifier']]],
  ['frequentitem_158',['FrequentItem',['../classtoolbox_1_1_transaction_data_set.html#a027898f9d144e38a2b3255fa6ff2c186',1,'toolbox::TransactionDataSet']]]
];
