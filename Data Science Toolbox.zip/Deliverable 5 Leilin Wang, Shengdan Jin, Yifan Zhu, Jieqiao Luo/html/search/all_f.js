var searchData=
[
  ['random_5fprojection_5fhash_73',['random_projection_hash',['../classtoolbox_1_1lshk_n_n_classifier.html#ac74b2b214b9497f606fe980d3ea7ed30',1,'toolbox::lshkNNClassifier']]],
  ['remove_5fnumber_74',['remove_number',['../classtoolbox_1_1_text_data_set.html#ab05865f908dab5efb10dd5ad373f7875',1,'toolbox::TextDataSet']]],
  ['remove_5fpunctuation_75',['remove_punctuation',['../classtoolbox_1_1_text_data_set.html#a1f23798ca4dfeac40bffeb7f3ddefdc6',1,'toolbox::TextDataSet']]],
  ['removecolumn_76',['removeColumn',['../classtoolbox_1_1_data_set.html#a21ebdd6274fce8511da055c28b48a17f',1,'toolbox.DataSet.removeColumn()'],['../classtoolbox_1_1_qual_data_set.html#a8ef7d4dee554cd5809e4c6493391488c',1,'toolbox.QualDataSet.removeColumn()']]],
  ['roc_5fcurve_77',['ROC_Curve',['../classtoolbox_1_1_experiment.html#abc02780b38debb0f7ceed0ca0ed58aa5',1,'toolbox::Experiment']]],
  ['rowcount_78',['rowcount',['../classtoolbox_1_1_data_set.html#a2caa7f53b9020e0705b021416ff0231d',1,'toolbox::DataSet']]],
  ['rule_79',['Rule',['../classtoolbox_1_1_transaction_data_set_1_1_rule.html',1,'toolbox::TransactionDataSet']]],
  ['runcrossval_80',['runCrossVal',['../classtoolbox_1_1_experiment.html#a0509690464f163d1787532207ee3edd8',1,'toolbox::Experiment']]]
];
