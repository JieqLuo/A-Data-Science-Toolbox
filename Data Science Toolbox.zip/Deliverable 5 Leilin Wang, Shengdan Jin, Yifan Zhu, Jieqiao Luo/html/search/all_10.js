var searchData=
[
  ['savetocsv_81',['savetoCSV',['../classtoolbox_1_1_data_set.html#a449f57933fcbdbd494852471d4830bdc',1,'toolbox::DataSet']]],
  ['score_82',['score',['../classtoolbox_1_1_experiment.html#a73168be4c17b1c7ae07c873eb4fdf534',1,'toolbox::Experiment']]],
  ['select_83',['select',['../classtoolbox_1_1_heterogenous_data_sets.html#a1057bd1e06b009711f11467b2b1146ac',1,'toolbox::HeterogenousDataSets']]],
  ['setcolumnname_84',['setColumnName',['../classtoolbox_1_1_data_set.html#aa4831a4bef70996b85d6640d5ddb0a87',1,'toolbox::DataSet']]],
  ['setk_85',['setK',['../classtoolbox_1_1simplek_n_n_classifier.html#ad89022fbf9d6d1764fa08ca9b7869a18',1,'toolbox.simplekNNClassifier.setK()'],['../classtoolbox_1_1kd_tree_k_n_n_classifier.html#a37f43574683f6a2727bb4750fa8c3fab',1,'toolbox.kdTreeKNNClassifier.setK()']]],
  ['setperiod_86',['setPeriod',['../classtoolbox_1_1_time_series_data_set.html#a0e037abbf6d323dc5afbecbe5d229857',1,'toolbox::TimeSeriesDataSet']]],
  ['setratio_87',['setRatio',['../classtoolbox_1_1_classifier_algorithm.html#a87ee6d4ca0d61a8022ed5810c16340bf',1,'toolbox::ClassifierAlgorithm']]],
  ['settype_88',['setType',['../classtoolbox_1_1_decision_tree.html#ae4da3a261dc9e6375181af54dab4c4ac',1,'toolbox::DecisionTree']]],
  ['simpleknnclassifier_89',['simplekNNClassifier',['../classtoolbox_1_1simplek_n_n_classifier.html',1,'toolbox']]],
  ['sort_90',['sort',['../classtoolbox_1_1_time_series_data_set.html#a20c4b43be15a7e5d2972ff8f6342baf0',1,'toolbox.TimeSeriesDataSet.sort()'],['../classtoolbox_1_1_quant_data_set.html#a9852fcf0ea29472ebcbc0e5ba6c67772',1,'toolbox.QuantDataSet.sort()']]],
  ['splittraintest_91',['splitTrainTest',['../classtoolbox_1_1_classifier_algorithm.html#aae623c8036a016ec152e3f2c15e79d00',1,'toolbox::ClassifierAlgorithm']]],
  ['stemming_92',['stemming',['../classtoolbox_1_1_text_data_set.html#a71772ac7998c15e17521f75127fc48d5',1,'toolbox::TextDataSet']]],
  ['stop_5fwords_93',['stop_words',['../classtoolbox_1_1_text_data_set.html#a6d4e45049dd751f3b5ca69ece19b7599',1,'toolbox::TextDataSet']]],
  ['summary_94',['summary',['../classtoolbox_1_1_data_set.html#a9cebf19b2e2b4c472867a3ef0ae7ebdf',1,'toolbox.DataSet.summary()'],['../classtoolbox_1_1_time_series_data_set.html#af3a8974d47fe6f4b49d0b725d79fba50',1,'toolbox.TimeSeriesDataSet.summary()'],['../classtoolbox_1_1_quant_data_set.html#a79ead1a817e6aa3d26a9d096864078fe',1,'toolbox.QuantDataSet.summary()'],['../classtoolbox_1_1_qual_data_set.html#a03e0431c7de26abcda0968649c5d1576',1,'toolbox.QualDataSet.summary()'],['../classtoolbox_1_1_transaction_data_set.html#ab0c2ae73b3d9e4e1b448cc46ac212b76',1,'toolbox.TransactionDataSet.summary()'],['../classtoolbox_1_1_heterogenous_data_sets.html#a60b69b93c8a395e9d33d33bcfcc7f4f3',1,'toolbox.HeterogenousDataSets.summary()']]]
];
