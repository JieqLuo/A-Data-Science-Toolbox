var searchData=
[
  ['iteration_5fk_5ffrom_5fcandidate_5fk_51',['Iteration_k_from_candidate_k',['../classtoolbox_1_1_transaction_data_set_1_1_rule.html#a1cb4cff3724a85c72626fe0e8634311d',1,'toolbox::TransactionDataSet::Rule']]]
];
