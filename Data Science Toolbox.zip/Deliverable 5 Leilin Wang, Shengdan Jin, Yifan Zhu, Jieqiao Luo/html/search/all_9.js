var searchData=
[
  ['k_52',['k',['../classtoolbox_1_1simplek_n_n_classifier.html#a8bdf9a50414c3e4c8277a354b3833425',1,'toolbox.simplekNNClassifier.k()'],['../classtoolbox_1_1lshk_n_n_classifier.html#aa031dbb2b1b69b75e851de15634de4f2',1,'toolbox.lshkNNClassifier.k()'],['../classtoolbox_1_1kd_tree_k_n_n_classifier.html#a230ef4a98022f6438a3fe282400b4098',1,'toolbox.kdTreeKNNClassifier.k()']]],
  ['k_5fnearest_5fneighbor_53',['k_nearest_neighbor',['../classtoolbox_1_1kd_tree_k_n_n_classifier_1_1_kd_tree.html#a3fa58175c71cf4f25e19e359305c4075',1,'toolbox::kdTreeKNNClassifier::KdTree']]],
  ['kdtree_54',['KdTree',['../classtoolbox_1_1kd_tree_k_n_n_classifier_1_1_kd_tree.html',1,'toolbox::kdTreeKNNClassifier']]],
  ['kdtreeknnclassifier_55',['kdTreeKNNClassifier',['../classtoolbox_1_1kd_tree_k_n_n_classifier.html',1,'toolbox']]]
];
