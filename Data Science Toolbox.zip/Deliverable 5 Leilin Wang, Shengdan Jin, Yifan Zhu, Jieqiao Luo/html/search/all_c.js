var searchData=
[
  ['node_63',['Node',['../classtoolbox_1_1kd_tree_k_n_n_classifier_1_1_kd_tree_1_1_node.html',1,'toolbox::kdTreeKNNClassifier::KdTree']]],
  ['ntht_64',['NtHt',['../classtoolbox_1_1_decision_tree.html#a1162ee9ef544d3d4f7e55bc6b7ec97b2',1,'toolbox::DecisionTree']]]
];
