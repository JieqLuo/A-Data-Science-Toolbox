var searchData=
[
  ['stop_5fwords_221',['stop_words',['../classtoolbox_1_1_text_data_set.html#a6d4e45049dd751f3b5ca69ece19b7599',1,'toolbox::TextDataSet']]]
];
