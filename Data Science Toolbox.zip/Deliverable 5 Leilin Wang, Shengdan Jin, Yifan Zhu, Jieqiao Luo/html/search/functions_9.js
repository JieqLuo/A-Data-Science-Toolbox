var searchData=
[
  ['k_5fnearest_5fneighbor_172',['k_nearest_neighbor',['../classtoolbox_1_1kd_tree_k_n_n_classifier_1_1_kd_tree.html#a3fa58175c71cf4f25e19e359305c4075',1,'toolbox::kdTreeKNNClassifier::KdTree']]]
];
