var searchData=
[
  ['classifieralgorithm_115',['ClassifierAlgorithm',['../classtoolbox_1_1_classifier_algorithm.html',1,'toolbox']]]
];
