var searchData=
[
  ['facts_5ftexts_211',['facts_texts',['../classtoolbox_1_1_text_data_set.html#adc90745ad8a9c9f8a23f00a8a3b11e94',1,'toolbox::TextDataSet']]],
  ['file_212',['file',['../classtoolbox_1_1_data_set.html#a859cf76bc4c2fa8e9bf36e364c7c96f5',1,'toolbox::DataSet']]],
  ['filt_5fds_213',['filt_ds',['../classtoolbox_1_1_time_series_data_set.html#a0ec62ca15687614aa97f7db6e945b747',1,'toolbox::TimeSeriesDataSet']]]
];
