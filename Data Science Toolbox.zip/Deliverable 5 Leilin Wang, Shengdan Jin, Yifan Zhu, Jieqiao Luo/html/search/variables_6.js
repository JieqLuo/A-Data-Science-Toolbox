var searchData=
[
  ['period_217',['period',['../classtoolbox_1_1_time_series_data_set.html#a98a4710c70c8bc3d4f9bd1862bcc5867',1,'toolbox::TimeSeriesDataSet']]],
  ['prediction_218',['prediction',['../classtoolbox_1_1_classifier_algorithm.html#a327be5a4433e853f225b2d6e2e397a8a',1,'toolbox.ClassifierAlgorithm.prediction()'],['../classtoolbox_1_1_decision_tree.html#ad0197259f1aee081f41a27304da4dbdb',1,'toolbox.DecisionTree.prediction()'],['../classtoolbox_1_1_experiment.html#a39b0947a9358cd3bd709779a7964795b',1,'toolbox.Experiment.prediction()']]],
  ['prediction_5fscore_219',['prediction_score',['../classtoolbox_1_1_classifier_algorithm.html#a6c1bf35dd9ed613892f7e05479e4ef08',1,'toolbox.ClassifierAlgorithm.prediction_score()'],['../classtoolbox_1_1_experiment.html#aa39f822bcc5a43605ce61856fdcb4bc6',1,'toolbox.Experiment.prediction_score()']]]
];
