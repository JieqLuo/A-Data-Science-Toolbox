var searchData=
[
  ['datasets_149',['datasets',['../classtoolbox_1_1_heterogenous_data_sets.html#a2fcfb545ad8a57dcaf23d81c17728fb5',1,'toolbox::HeterogenousDataSets']]],
  ['devide_5fgroup_150',['devide_group',['../classtoolbox_1_1_decision_tree.html#a2c86824ba0b784cbe4da92cfad2f81da',1,'toolbox::DecisionTree']]],
  ['devide_5fgroup_5fdiscrete_151',['devide_group_discrete',['../classtoolbox_1_1_decision_tree.html#acfd5bb2f4cd6245fb4470f69ad2e302d',1,'toolbox::DecisionTree']]],
  ['distance_152',['distance',['../classtoolbox_1_1kd_tree_k_n_n_classifier_1_1_kd_tree.html#a400f720eb703c038aa6f610a501005dd',1,'toolbox::kdTreeKNNClassifier::KdTree']]],
  ['drawconfusionmatrix_153',['drawConfusionMatrix',['../classtoolbox_1_1_experiment.html#a94358318ea500565df541ed62f86125d',1,'toolbox::Experiment']]],
  ['drawprediction_154',['drawPrediction',['../classtoolbox_1_1_classifier_algorithm.html#adc957b46d0daf8210d24455348a5f215',1,'toolbox::ClassifierAlgorithm']]]
];
