var searchData=
[
  ['classifier_206',['classifier',['../classtoolbox_1_1_experiment.html#aab8f63d8228866e897b9025cc145bf9c',1,'toolbox::Experiment']]],
  ['columncount_207',['columncount',['../classtoolbox_1_1_data_set.html#a21651b88f1c8ffe7a32c6b97d00dc8f8',1,'toolbox::DataSet']]]
];
