var searchData=
[
  ['dataset_18',['DataSet',['../classtoolbox_1_1_data_set.html',1,'toolbox']]],
  ['dataset_5fsplit_19',['dataset_split',['../classtoolbox_1_1_experiment.html#abe72f42853ffe95b95e2695148f10391',1,'toolbox::Experiment']]],
  ['datasets_20',['datasets',['../classtoolbox_1_1_heterogenous_data_sets.html#a2fcfb545ad8a57dcaf23d81c17728fb5',1,'toolbox::HeterogenousDataSets']]],
  ['decisionnode_21',['decisionnode',['../classtoolbox_1_1_decision_tree_1_1decisionnode.html',1,'toolbox::DecisionTree']]],
  ['decisiontree_22',['DecisionTree',['../classtoolbox_1_1_decision_tree.html',1,'toolbox']]],
  ['devide_5fgroup_23',['devide_group',['../classtoolbox_1_1_decision_tree.html#a2c86824ba0b784cbe4da92cfad2f81da',1,'toolbox::DecisionTree']]],
  ['devide_5fgroup_5fdiscrete_24',['devide_group_discrete',['../classtoolbox_1_1_decision_tree.html#acfd5bb2f4cd6245fb4470f69ad2e302d',1,'toolbox::DecisionTree']]],
  ['distance_25',['distance',['../classtoolbox_1_1kd_tree_k_n_n_classifier_1_1_kd_tree.html#a400f720eb703c038aa6f610a501005dd',1,'toolbox::kdTreeKNNClassifier::KdTree']]],
  ['drawconfusionmatrix_26',['drawConfusionMatrix',['../classtoolbox_1_1_experiment.html#a94358318ea500565df541ed62f86125d',1,'toolbox::Experiment']]],
  ['drawprediction_27',['drawPrediction',['../classtoolbox_1_1_classifier_algorithm.html#adc957b46d0daf8210d24455348a5f215',1,'toolbox::ClassifierAlgorithm']]],
  ['ds_28',['ds',['../classtoolbox_1_1_data_set.html#a9035addde6a384c0eed5edf06b741a2b',1,'toolbox.DataSet.ds()'],['../classtoolbox_1_1_transaction_data_set.html#a9cfe5adcb904a4b5c10fe12c2e688812',1,'toolbox.TransactionDataSet.ds()'],['../classtoolbox_1_1_experiment.html#ad0448350f75147f6356af582d38919e3',1,'toolbox.Experiment.ds()']]],
  ['ds_5ftype_29',['ds_type',['../classtoolbox_1_1_time_series_data_set.html#a92bf4fbd00ce4ace923e42a97b5f439b',1,'toolbox::TimeSeriesDataSet']]]
];
