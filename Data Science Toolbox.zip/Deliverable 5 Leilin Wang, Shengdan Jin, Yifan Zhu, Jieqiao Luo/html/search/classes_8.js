var searchData=
[
  ['rule_128',['Rule',['../classtoolbox_1_1_transaction_data_set_1_1_rule.html',1,'toolbox::TransactionDataSet']]]
];
