var searchData=
[
  ['k_214',['k',['../classtoolbox_1_1simplek_n_n_classifier.html#a8bdf9a50414c3e4c8277a354b3833425',1,'toolbox.simplekNNClassifier.k()'],['../classtoolbox_1_1lshk_n_n_classifier.html#aa031dbb2b1b69b75e851de15634de4f2',1,'toolbox.lshkNNClassifier.k()'],['../classtoolbox_1_1kd_tree_k_n_n_classifier.html#a230ef4a98022f6438a3fe282400b4098',1,'toolbox.kdTreeKNNClassifier.k()']]]
];
