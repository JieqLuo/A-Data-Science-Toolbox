var searchData=
[
  ['period_65',['period',['../classtoolbox_1_1_time_series_data_set.html#a98a4710c70c8bc3d4f9bd1862bcc5867',1,'toolbox::TimeSeriesDataSet']]],
  ['perioddata_66',['PeriodData',['../classtoolbox_1_1_time_series_data_set.html#a38a39ca4f30b3c76fb508c924b4f66a0',1,'toolbox::TimeSeriesDataSet']]],
  ['permutation_67',['permutation',['../classtoolbox_1_1_decision_tree.html#a96dd47d265326547c69683b3bbad0aa7',1,'toolbox::DecisionTree']]],
  ['prediction_68',['prediction',['../classtoolbox_1_1_classifier_algorithm.html#a327be5a4433e853f225b2d6e2e397a8a',1,'toolbox.ClassifierAlgorithm.prediction()'],['../classtoolbox_1_1_decision_tree.html#ad0197259f1aee081f41a27304da4dbdb',1,'toolbox.DecisionTree.prediction()'],['../classtoolbox_1_1_experiment.html#a39b0947a9358cd3bd709779a7964795b',1,'toolbox.Experiment.prediction()']]],
  ['prediction_5fscore_69',['prediction_score',['../classtoolbox_1_1_classifier_algorithm.html#a6c1bf35dd9ed613892f7e05479e4ef08',1,'toolbox.ClassifierAlgorithm.prediction_score()'],['../classtoolbox_1_1_experiment.html#aa39f822bcc5a43605ce61856fdcb4bc6',1,'toolbox.Experiment.prediction_score()']]],
  ['predictscore_70',['predictScore',['../classtoolbox_1_1_decision_tree.html#ac8064df620993e486281d0c208bfb440',1,'toolbox::DecisionTree']]]
];
