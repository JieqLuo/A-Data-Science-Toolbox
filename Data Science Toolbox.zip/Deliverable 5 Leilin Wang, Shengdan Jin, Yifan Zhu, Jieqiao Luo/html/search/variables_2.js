var searchData=
[
  ['dataset_5fsplit_208',['dataset_split',['../classtoolbox_1_1_experiment.html#abe72f42853ffe95b95e2695148f10391',1,'toolbox::Experiment']]],
  ['ds_209',['ds',['../classtoolbox_1_1_data_set.html#a9035addde6a384c0eed5edf06b741a2b',1,'toolbox.DataSet.ds()'],['../classtoolbox_1_1_transaction_data_set.html#a9cfe5adcb904a4b5c10fe12c2e688812',1,'toolbox.TransactionDataSet.ds()'],['../classtoolbox_1_1_experiment.html#ad0448350f75147f6356af582d38919e3',1,'toolbox.Experiment.ds()']]],
  ['ds_5ftype_210',['ds_type',['../classtoolbox_1_1_time_series_data_set.html#a92bf4fbd00ce4ace923e42a97b5f439b',1,'toolbox::TimeSeriesDataSet']]]
];
