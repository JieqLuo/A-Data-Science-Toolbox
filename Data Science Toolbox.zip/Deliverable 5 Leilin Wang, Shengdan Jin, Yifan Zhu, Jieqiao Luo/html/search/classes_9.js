var searchData=
[
  ['simpleknnclassifier_129',['simplekNNClassifier',['../classtoolbox_1_1simplek_n_n_classifier.html',1,'toolbox']]]
];
