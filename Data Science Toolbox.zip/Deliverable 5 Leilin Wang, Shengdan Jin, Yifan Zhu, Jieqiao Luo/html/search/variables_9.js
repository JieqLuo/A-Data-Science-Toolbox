var searchData=
[
  ['testds_222',['testDS',['../classtoolbox_1_1_classifier_algorithm.html#a329a214b7a8873a6fdde3a4d64a9aaac',1,'toolbox::ClassifierAlgorithm']]],
  ['texts_223',['texts',['../classtoolbox_1_1_text_data_set.html#a1cecfa36942502a6f233fac0d4be622a',1,'toolbox::TextDataSet']]],
  ['trainds_224',['trainDS',['../classtoolbox_1_1_classifier_algorithm.html#ad65cece22f047aa5a63a07bb609ccd51',1,'toolbox::ClassifierAlgorithm']]],
  ['trainl_225',['trainL',['../classtoolbox_1_1_classifier_algorithm.html#a12b7214f03b646c2003b6b9338c9e9c1',1,'toolbox.ClassifierAlgorithm.trainL()'],['../classtoolbox_1_1lshk_n_n_classifier.html#a4a49476d191cbacaf99f2b5b2555a901',1,'toolbox.lshkNNClassifier.trainL()']]],
  ['traintestratio_226',['trainTestRatio',['../classtoolbox_1_1_classifier_algorithm.html#a7cba616ca33003bbf17e9b2e7c69d51d',1,'toolbox::ClassifierAlgorithm']]],
  ['trans_227',['trans',['../classtoolbox_1_1_transaction_data_set.html#ab6530f986e6242af64ad79f158b2cf8e',1,'toolbox::TransactionDataSet']]],
  ['tree_228',['tree',['../classtoolbox_1_1_decision_tree.html#a922f15890acbba3840f27fecdf8bd15f',1,'toolbox::DecisionTree']]],
  ['true_229',['true',['../classtoolbox_1_1_experiment.html#a6b6c71e7bf89b0b6a2d6411212db872b',1,'toolbox::Experiment']]],
  ['type_230',['type',['../classtoolbox_1_1_decision_tree.html#a91cf40ac63b762e8ddb7cb1595783643',1,'toolbox::DecisionTree']]]
];
